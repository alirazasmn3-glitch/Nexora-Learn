const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');
const path = require('path');
const OpenAI = require('openai');

dotenv.config({ path: path.join(__dirname, '..', '.env') });

const app = express();
const PORT = Number(process.env.PORT || 3000);
const ROOT = path.join(__dirname, '..');

app.use(cors());
app.use(express.json({ limit: '15mb' }));
app.use(express.static(ROOT));

const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
const model = process.env.OPENAI_MODEL || 'gpt-5.6-luna';

app.get('/api/health', (req, res) => {
  res.json({
    success: true,
    backend: 'Nexora Learn',
    openaiConfigured: Boolean(process.env.OPENAI_API_KEY),
    model
  });
});

app.post('/api/ask', async (req, res) => {
  try {
    const question = typeof req.body.question === 'string' ? req.body.question.trim() : '';
    const subject = typeof req.body.subject === 'string' ? req.body.subject.trim() : 'General';

    if (!question) {
      return res.status(400).json({ success: false, error: 'Please enter a question.' });
    }
    if (!process.env.OPENAI_API_KEY) {
      return res.status(500).json({ success: false, error: 'OPENAI_API_KEY is missing in .env' });
    }

    const response = await client.responses.create({
      model,
      input: `You are Nexora Learn, a professional educational AI tutor.

Subject:
${subject}

Help a school or college student understand the question.

Rules:
1. Give the correct answer.
2. Explain the solution step by step.
3. Use simple student-friendly language.
4. For mathematics, show calculations clearly.
5. For science, explain the concept clearly.
6. For programming, provide correct code when needed and explain it.
7. If the question is ambiguous, say what information is missing.
8. Do not invent information.
9. Organize the answer with headings or numbered steps when useful.

Student question:
${question}`
    });

    res.json({ success: true, answer: response.output_text || 'AI نے کوئی جواب نہیں دیا۔' });
  } catch (error) {
    console.error('TEXT AI ERROR:', error);
    res.status(500).json({ success: false, error: error?.message || 'AI سے جواب حاصل نہیں ہو سکا۔' });
  }
});

app.post('/api/ask-image', async (req, res) => {
  try {
    const image = typeof req.body.image === 'string' ? req.body.image : '';
    const question = typeof req.body.question === 'string' ? req.body.question.trim() : '';
    const subject = typeof req.body.subject === 'string' ? req.body.subject.trim() : 'General';

    if (!image) {
      return res.status(400).json({ success: false, error: 'Image نہیں ملی۔' });
    }
    if (!image.startsWith('data:image/')) {
      return res.status(400).json({ success: false, error: 'Invalid image format.' });
    }
    if (!process.env.OPENAI_API_KEY) {
      return res.status(500).json({ success: false, error: 'OPENAI_API_KEY is missing in .env' });
    }

    const response = await client.responses.create({
      model,
      input: [{
        role: 'user',
        content: [
          {
            type: 'input_text',
            text: `You are Nexora Learn, an educational AI tutor.

Subject:
${subject}

Carefully inspect the uploaded image. If it contains a school or college question: read it carefully, identify what is being asked, solve it correctly, explain step by step, use simple student-friendly language, show calculations clearly for mathematics, explain concepts clearly for science, and provide correct programming solutions when needed. If the image is unclear, do not guess.

Student's additional question:
${question || 'Please solve the question shown in this image step by step.'}`
          },
          { type: 'input_image', image_url: image }
        ]
      }]
    });

    res.json({ success: true, answer: response.output_text || 'AI تصویر سے جواب نہیں دے سکا۔' });
  } catch (error) {
    console.error('IMAGE AI ERROR:', error);
    res.status(500).json({ success: false, error: error?.message || 'Image کو AI سمجھ نہیں سکا۔' });
  }
});

app.use((req, res) => {
  res.sendFile(path.join(ROOT, 'index.html'));
});

app.listen(PORT, () => {
  console.log('======================================');
  console.log('Nexora Learn Backend Started');
  console.log(`http://localhost:${PORT}`);
  console.log(`Model: ${model}`);
  console.log('======================================');
});
